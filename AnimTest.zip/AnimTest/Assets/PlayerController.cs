﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    float speed = 10.0f;
    Animator playerAnim;
    
    // Start is called before the first frame update
    void Start()
    {
        playerAnim = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.W))
            {
            
            playerAnim.SetBool("IsStrafe", true);
            transform.Translate(Vector3.forward * Time.deltaTime * speed);
        }   
        if(Input.GetKeyUp(KeyCode.W))
        {
            playerAnim.SetBool("IsStrafe", false);

        }
        if(Input.GetKeyDown(KeyCode.Space))
        {
            playerAnim.SetTrigger("trigAttack");
        }
        
        
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Cube"))
        {
            playerAnim.SetTrigger("Death");
        }
    }
}
