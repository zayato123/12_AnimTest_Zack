﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    float speed = 10.0f;
    Animator playerAnim;
    
    // Start is called before the first frame update
    void Start()
    {
        playerAnim = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.W))
        {

            playerAnim.SetBool("IsStrafe", true);
            transform.Translate(Vector3.forward * Time.deltaTime * speed);
            transform.rotation = Quaternion.Euler(0, 0, 0);
        }
        if (Input.GetKeyUp(KeyCode.W))
        {
            playerAnim.SetBool("IsStrafe", false);

        }
        if (Input.GetKeyDown(KeyCode.Space))
        {
            playerAnim.SetTrigger("trigAttack");
        }
        if (Input.GetKey(KeyCode.S))
        {

            playerAnim.SetBool("IsStrafe", true);
            transform.Translate(Vector3.forward * Time.deltaTime * speed);
            transform.rotation = Quaternion.Euler(0, 180, 0);
        }
        if (Input.GetKeyUp(KeyCode.S))
        {
            playerAnim.SetBool("IsStrafe", false);
        }
        if (Input.GetKey(KeyCode.D))
        {

            playerAnim.SetBool("IsStrafe", true);
            transform.Translate(Vector3.forward * Time.deltaTime * speed);
            transform.rotation = Quaternion.Euler(0, 90, 0);
        }
        if (Input.GetKeyUp(KeyCode.D))
        {
            playerAnim.SetBool("IsStrafe", false);
        }
        if (Input.GetKey(KeyCode.A))
        {

            playerAnim.SetBool("IsStrafe", true);
            transform.Translate(Vector3.forward * Time.deltaTime * speed);
            transform.rotation = Quaternion.Euler(0, -90, 0);
        }
        if (Input.GetKeyUp(KeyCode.A))
        {
            playerAnim.SetBool("IsStrafe", false);
        }
    }
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Cube"))
        {
            playerAnim.SetTrigger("Death");
        }
    }
}
